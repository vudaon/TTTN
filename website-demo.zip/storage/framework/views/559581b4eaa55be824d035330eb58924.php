
  <?php $__env->startSection('title'); ?>
        <title>Trang chủ</title>
      <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Starter Page</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Starter Page</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <a href="<?php echo e(route('airplanes.create')); ?>" class="btn-btn-success float-right m-2">Add account</a>
            </div>
            <div class="col-sm-12">
                 <table class="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Code</th>
                    <th scope="col">Numbers of fly</th>
                    <th scope="col">Create at</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                     <?php $__currentLoopData = $airplanes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airplane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($airplane->id); ?></th>
                    <th ><a href="aftercheck/<?php echo e($airplane->id); ?>"><?php echo e($airplane->name); ?></a></th>
                    <td><?php echo e($airplane->code); ?></td>
                    <td><?php echo e($airplane->count_fly); ?></td>
                    <td><?php echo e($airplane->created_at); ?></td>
                    <td><a href="airplanes/<?php echo e($airplane->id); ?>/edit">Edit</a></td>
                    <td><form action="/airplanes/<?php echo e($airplane->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger">
                        Delete
                    </button>
                </form></td>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
              <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/airplanes/home.blade.php ENDPATH**/ ?>