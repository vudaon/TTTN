<?php
use Carbon\Carbon;
?>

<?php $__env->startSection('title'); ?>
    <title>Trang chủ</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Edit CheckList Page</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Edit CheckList Page</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <form action="/checklist/<?php echo e($checklist->id); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div>
                            <label for="flytimes">Fly time:</label>
                            <input class="form-control" name="flytimes" value="<?php echo e(old('flytimes', $checklist->flight_number)); ?>">
                            <?php if($errors->has('flytimes')): ?>
                                <span class="text-danger"><?php echo e($errors->first('flytimes')); ?></span>
                            <?php endif; ?>
                        </div>
                        <br>
                        <div>
                            <?php
                            // Chuyển đổi thời gian sang định dạng phù hợp cho datetime-local
                            try {
                                $formattedTime = Carbon::createFromFormat('d/m/Y H:i:s', $checklist->time)->format('Y-m-d\TH:i');
                            } catch (\Exception $e) {
                                $formattedTime = '';
                            }
                            ?>
                            <label for="time">Time:</label>
                            <input type="datetime-local" class="form-control" name="time" value="<?php echo e(old('time', $formattedTime)); ?>">
                            <?php if($errors->has('time')): ?>
                                <span class="text-danger"><?php echo e($errors->first('time')); ?></span>
                            <?php endif; ?>
                        </div>
                        <br>
                        <div>
                            <label for="airplane_id">Choose airplane check:</label>
                            <select class="form-select" name="airplane_id">
                                <?php $__currentLoopData = $airplanes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airplane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($airplane->id); ?>" <?php echo e(old('airplane_id', $checklist->airplane_id) == $airplane->id ? 'selected' : ''); ?>>
                                        <?php echo e($airplane->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('airplane_id')): ?>
                                <span class="text-danger"><?php echo e($errors->first('airplane_id')); ?></span>
                            <?php endif; ?>
                        </div>
                        <br>
                        <button class="btn btn-primary" type="submit">
                            Update
                        </button>
                    </form>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/checklist/edit.blade.php ENDPATH**/ ?>