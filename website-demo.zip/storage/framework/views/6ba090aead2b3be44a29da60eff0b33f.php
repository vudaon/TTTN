
<?php $__env->startSection('title'); ?>
    <title>Trang chủ</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Edit Airplane Page</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Edit Airplane Page</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <form action="/airplanes/<?php echo e($airplanes->id); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="name">Name aircraft:</label>
                            <input class="form-control" name="name" value="<?php echo e(old('name', $airplanes->name)); ?>">
                            <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="code">Code:</label>
                            <input class="form-control" name="code" value="<?php echo e(old('code', $airplanes->code)); ?>">
                            <?php if($errors->has('code')): ?>
                                <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                            <?php endif; ?>
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="numbers">Numbers of fly:</label>
                            <input class="form-control" name="numbers" value="<?php echo e(old('numbers', $airplanes->count_fly)); ?>">
                            <?php if($errors->has('numbers')): ?>
                                <span class="text-danger"><?php echo e($errors->first('numbers')); ?></span>
                            <?php endif; ?>
                        </div>
                        <br>
                        <button class="btn btn-primary" type="submit">
                            Update
                        </button>
                    </form>
                 </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/airplanes/edit.blade.php ENDPATH**/ ?>