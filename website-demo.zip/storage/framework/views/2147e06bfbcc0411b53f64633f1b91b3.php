
  <?php $__env->startSection('title'); ?>
        <title>Trang chủ</title>
      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Edit User Page</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit User Page</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h3>Update account</h3>
                
                <form action="/users/<?php echo e($users->id); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?> 
                    <label for="name">Name:</label>
                    <input class="form-control" value="<?php echo e(old('name',$users->name)); ?>" name="name">
                     <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                    <br>
                    <label for="email">Email:</label>
                    <input class="form-control" value="<?php echo e(old('email',$users->email)); ?>" name="email">
                     <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                    <br>
                    <label for="password">Password:</label>
                    <input class="form-control" value="<?php echo e(old('password',$users->password)); ?>" name="password">
                     <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                    <br>
                    <label for="phone">Phone Number:</label>
                    <input class="form-control" value="<?php echo e(old('phone',$users->phone_number)); ?>" name="phone">
                     <?php if($errors->has('phone')): ?>
                                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                            <?php endif; ?>
                    <br>
                    <label for="address">Address:</label>
                    <input class="form-control" value="<?php echo e($users->address); ?>" name="address"><br>
                    <label for="gender">Gender:</label>
                    <input class="form-control" value="<?php echo e($users->gender); ?>" name="gender"><br>
                    <button class="btn btn-primary" type="submit">
                        Update
                    </button>
                    
                </form>
                </div>
              <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/users/edit.blade.php ENDPATH**/ ?>