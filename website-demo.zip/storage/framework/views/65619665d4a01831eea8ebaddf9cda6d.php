
  <?php $__env->startSection('title'); ?>
        <title>Trang chủ</title>
      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Edit After Category Page</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit After Category Page</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
                <form action="/categoriesafter/<?php echo e($categories->id); ?>" method="post">    
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>        
                  <label for="name">Name category:</label>
                  <input 
                    class="form-control"
                    type="text" 
                    name="name"
                    value="<?php echo e($categories->item_category); ?>"><br>
                    <label for="require">Requirment:</label>
                    <input 
                    class="form-control"
                    type="text" 
                    name="require"
                    value="<?php echo e($categories->requirement); ?>"><br>
                    <label for="method">Method of Examining:</label>
                    <input 
                    class="form-control"
                    type="text" 
                    name="method"
                    value="<?php echo e($categories->check_method); ?>"><br>
                    <label for="result">Result:</label>
                    <input 
                    class="form-control"
                    type="text" 
                    name="result"
                    value="<?php echo e($categories->result); ?>"><br>
                    <label for="evaluation">Evaluation:</label>
                    <input 
                    class="form-control"
                    type="text" 
                    name="evaluation"
                    value="<?php echo e($categories->evaluation); ?>"><br>
                    <label for="note">Note:</label>        
                    <input 
                    class="form-control"
                    type="text" 
                    name="note"
                    value="<?php echo e($categories->note); ?>"><br>
                <button 
                    class="btn btn-primary"
                    type="submit">
                    Update
                </button>
              </form>
              </div>
    
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/categoriesafter/edit.blade.php ENDPATH**/ ?>