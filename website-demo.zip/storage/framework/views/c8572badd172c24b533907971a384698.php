
  <?php $__env->startSection('title'); ?>
        <title>Trang chủ</title>
      <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Management AfterList Page</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item">Home</li>
              <li class="breadcrumb-item active">Management AfterList Page</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <a href="<?php echo e(route('aftercheck.create')); ?>" class="btn-btn-success float-right m-2">Add new after check list</a>        
            </div>
            <div class="col-sm-12">
            <table class="table">
                 <thead>
                    <tr>
                    <th scope="col">#</th>              
                    <th scope="col">Time</th>
                    <th scope="col">Check List</th>
                    <th scope="col">Checker</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                     <?php $__currentLoopData = $afterlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afterlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>        
                    <td><?php echo e($afterlist->time); ?></td>
                          <?php switch($afterlist->flightcheck->flight_number):
                                  case (1): ?>
                                      <?php $suffix = 'st'; ?>
                                      <?php break; ?>

                                  <?php case (2): ?>
                                      <?php $suffix = 'nd'; ?>
                                      <?php break; ?>

                                  <?php case (3): ?>
                                      <?php $suffix = 'rd'; ?>
                                      <?php break; ?>

                                  <?php default: ?>
                                      <?php if($afterlist->flightcheck->flight_number >= 4): ?>
                                          <?php $suffix = 'th'; ?>
                                      <?php else: ?>
                                          <?php $suffix = ' (Invalid flight number)'; ?>
                                      <?php endif; ?>
                              <?php endswitch; ?>
                    <td>Flight <?php echo e($afterlist->flightcheck->airplane->name); ?> for the <?php echo e($afterlist->flightcheck->flight_number); ?><?php echo e($suffix); ?> time</td>
                    <td><?php echo e($afterlist->user->name); ?></td>
                    <td><a href="aftercheck/<?php echo e($afterlist->id); ?>/edit">Edit</a></td>
                    <td><form action="/aftercheck/<?php echo e($afterlist->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger">
                        Delete
                    </button>
                </form></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
              <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/aftercheck/index.blade.php ENDPATH**/ ?>