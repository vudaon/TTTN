
  <?php $__env->startSection('title'); ?>
        <title>Trang chủ</title>
      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Create Before Category Page</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Create Before Category Page</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
                <form action="<?php echo e(route('categoriesbefore.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name">Name category:</label>
                    <input class="form-control" type="text" id="name" name="name"><br>
                    <label for="require">Requirement:</label>
                    <input class="form-control" type="text" id="require" name="require"><br>
                    <label for="method">Method of Examining:</label>
                    <input class="form-control" type="text" id="method" name="method"><br>
                    <label for="result">Result:</label>
                    <input class="form-control" type="text" id="result" name="result"><br>
                    <label for="evaluation">Evaluation:</label>
                    <input class="form-control" type="text" id="evaluation" name="evaluation"><br>
                    <label for="note">Note:</label>
                    <input class="form-control" type="text" id="note" name="note"><br>
                    <div>
                        <label>Choose before list check:</label>
                        <select name="precheckid">
                          <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>">
                              PreList <?php echo e($list->time); ?>

                            </option>    
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                        </select>
                    </div>
                    <button class="btn btn-primary" type="submit">
                        Submit
                    </button>
                </form>
              </div>
    
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/categoriesbefore/create.blade.php ENDPATH**/ ?>