
  <?php $__env->startSection('title'); ?>
        <title>Trang chủ</title>
      <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Magement After Category List Page</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Magement After Category Page</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <a href="<?php echo e(route('categoriesafter.create')); ?>" class="btn-btn-success float-right m-2">Add new after category</a>
                <a href="<?php echo e(route('categoriesafter.export', ['category_name' => request()->input('category_name'), 'after_check_id' => request()->input('after_check_id')])); ?>" class="btn btn-success float-right m-2">Export data</a>
            </div>
            <div class="col-sm-12">
              <form  method="GET" class="mb-3">
                <div class="form-group">
                    <label for="category_name">Tìm kiếm theo tên danh mục:</label>
                    <input type="text" name="category_name" id="category_name" class="form-control" placeholder="Nhập tên danh mục"  value="<?php echo e(old('category_name', request()->input('category_name'))); ?>">
                </div>
                <div class="form-group">
                    <label for="after_check_id">Lọc theo Pre Check ID:</label>
                    <select name="after_check_id" id="after_check_id" class="form-control">
                        <option value="">Chọn tất cả</option>
                        <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>" <?php echo e(old('after_check_id', request()->input('after_check_id')) == $list->id ? 'selected' : ''); ?>>
                                <?php switch($list->flightcheck->flight_number):
                                  case (1): ?>
                                      <?php $suffix = 'st'; ?>
                                      <?php break; ?>

                                  <?php case (2): ?>
                                      <?php $suffix = 'nd'; ?>
                                      <?php break; ?>

                                  <?php case (3): ?>
                                      <?php $suffix = 'rd'; ?>
                                      <?php break; ?>

                                  <?php default: ?>
                                      <?php if($list->flightcheck->flight_number >= 4): ?>
                                          <?php $suffix = 'th'; ?>
                                      <?php else: ?>
                                          <?php $suffix = ' (Invalid flight number)'; ?>
                                      <?php endif; ?>
                              <?php endswitch; ?>
                    Flight <?php echo e($list->flightcheck->airplane->name); ?> for the <?php echo e($list->flightcheck->flight_number); ?><?php echo e($suffix); ?> time
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
              
                <button type="submit" class="btn btn-primary">Tìm kiếm</button>
            </form>

                 <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Category</th>
                    <th scope="col">Requirement</th>
                    <th scope="col">Method of Examining</th>
                    <th scope="col">Result</th>
                    <th scope="col">Evaluation</th>
                    <th scope="col">Note</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <th ><a href="aftercheck/<?php echo e($category->id); ?>"><?php echo e($category->item_category); ?></a></th>
                    <td><?php echo e($category->requirement); ?></td>
                    <td><?php echo e($category->check_method); ?></td>
                    <td><?php echo e($category->result); ?></td>
                    <td><?php echo e($category->evaluation); ?></td>
                    <td><?php echo e($category->note); ?></td>
                    <td><a href="categoriesafter/<?php echo e($category->id); ?>/edit">
                              Edit
                              </a></td>
                    <td><form action="/categoriesafter/<?php echo e($category->id); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('delete'); ?>
                                  <button type="submit" class="btn btn-danger">
                                      Delete
                                  </button>
                              </form></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
              <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/categoriesafter/index.blade.php ENDPATH**/ ?>