
<?php $__env->startSection('title'); ?>
    <title>Trang chủ</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Management Check List Page</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Management Check List</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!-- Main Content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row mb-3">
          <div class="col-sm-12">
            <a href="<?php echo e(route('checklist.create')); ?>" class="btn btn-success float-right m-2">Add new check list</a>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12">
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Flight Times</th>
                    <th>Time</th>
                    <th>Aircraft Tested</th>
                    <th></th>
                    <th></th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e($loop->iteration); ?></th>
                      <td><a href="<?php echo e(route('checklist.edit', $list->id)); ?>">Flight No.<?php echo e($list->flight_number); ?></a></td>
                      <td><?php echo e($list->time); ?></td>
                      <td><?php echo e($list->airplane->name); ?></td>
                      <td><a href="<?php echo e(route('checklist.show', ['checklist' => $list->id])); ?>?type=before" class="btn btn-info">Before Categories</a></td>
                      <td><a href="<?php echo e(route('checklist.show', ['checklist' => $list->id])); ?>?type=after" class="btn btn-info">After Categories</a></td>
                      <td>
                        <form action="<?php echo e(route('checklist.destroy', $list->id)); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="d-flex justify-content-center">
              <?php echo e($lists->links('vendor.pagination.bootstrap-4')); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/checklist/index.blade.php ENDPATH**/ ?>