
  <?php $__env->startSection('title'); ?>
        <title>Trang chủ</title>
      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Create Check List Page</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Create Check List Page</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
                  <form action="<?php echo e(route('checklist.store')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div>
                          <label for="flytimes">Fly time:</label>
                          <input class="form-control" name="flytimes" value="<?php echo e(old('flytimes')); ?>">
                          <?php if($errors->has('flytimes')): ?>
                              <span class="text-danger"><?php echo e($errors->first('flytimes')); ?></span>
                          <?php endif; ?>
                      </div>
                      <br>

                      <div>
                          <label for="time">Time:</label>
                          <input type="datetime-local" class="form-control" name="time" value="<?php echo e(old('time')); ?>">
                          <?php if($errors->has('time')): ?>
                              <span class="text-danger"><?php echo e($errors->first('time')); ?></span>
                          <?php endif; ?>
                      </div>
                      <br>

                      <div>
                          <label for="airplane_id">Choose airplane check:</label>
                          <select class="form-select" aria-label="Default select example" name="airplane_id">
                              <?php $__currentLoopData = $airplanes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airplane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($airplane->id); ?>" <?php echo e(old('airplane_id') == $airplane->id ? 'selected' : ''); ?>>
                                      <?php echo e($airplane->name); ?>

                                  </option>    
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                          </select>
                          <?php if($errors->has('airplane_id')): ?>
                              <span class="text-danger"><?php echo e($errors->first('airplane_id')); ?></span>
                          <?php endif; ?>
                      </div>
                      <br>
                      <button class="btn btn-primary" type="submit">
                          Submit
                      </button>
                  </form>
              </div>
             </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\website-demo\resources\views/checklist/create.blade.php ENDPATH**/ ?>